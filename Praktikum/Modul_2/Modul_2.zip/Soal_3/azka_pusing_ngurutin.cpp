#include <bits/stdc++.h>
using namespace std;

struct Node {
    string data;
    struct Node* left;
    struct Node* right;
    Node(const string& data)
    {
        this->data = data;
        left = right = NULL;
    }
};

void inOrder(struct Node* root)
{
    if (root == NULL) {
        return;
    }

    inOrder(root->left);
    cout << root->data << " ";
    inOrder(root->right);
}

Node* constructBinaryTree(vector<string>& inputStrings, int start, int end)
{
    if (start > end) {
        return NULL;
    }

    int mid = (start + end) / 2;
    Node* newNode = new Node(inputStrings[mid]);

    newNode->left = constructBinaryTree(inputStrings, start, mid - 1);
    newNode->right = constructBinaryTree(inputStrings, mid + 1, end);

    return newNode;
}

int main()
{
    vector<string> inputStrings;
    string input;

    cout << "Enter strings separated by spaces (enter 'exit' to stop):" << endl;

    while (cin >> input && input != "exit") {
        inputStrings.push_back(input);
    }

    sort(inputStrings.begin(), inputStrings.end()); // Sort the input strings for a balanced binary tree

    struct Node* root = constructBinaryTree(inputStrings, 0, inputStrings.size() - 1);

    cout << "In-order traversal of the constructed binary tree:" << endl;
    inOrder(root);

    return 0;
}
